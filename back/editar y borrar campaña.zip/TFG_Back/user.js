window.onload = function () {
    let edit = document.getElementById("edit")
    edit.addEventListener("click", edicion)
    let editPassword = document.getElementById("editPassword")
    editPassword.addEventListener("click", editarContrasena)
    function edicion() {
        let oldInfo = document.getElementById("infoUsuario")
        let changeInfo = document.getElementById("changeInfo")
        oldInfo.style.display = "none"
        changeInfo.style.display = "block"
    }
    function editarContrasena() {
        let oldInfo = document.getElementById("infoUsuario")
        let changePassword = document.getElementById("changePassword")
        oldInfo.style.display = "none"
        changePassword.style.display = "block"
    }



}