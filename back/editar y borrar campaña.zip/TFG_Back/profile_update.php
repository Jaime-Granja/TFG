<?php
session_start();
require 'conection.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $new_email = trim($_POST['email']);
    $new_username = trim($_POST['username']);

    // Validaciones básicas
    if (empty($new_email) || empty($new_username)) {
        die("Todos los campos son obligatorios.");
    }

    // Preparar la consulta para actualizar los datos del usuario
    try {
        $update_query = $dbConection->prepare("UPDATE Users SET username = :username, email = :email WHERE id = :user_id");
        $update_query->execute([
            ':username' => $new_username,
            ':email' => $new_email,
            ':user_id' => $user_id
        ]);

        echo "Perfil actualizado correctamente.";
    } catch (PDOException $e) {
        die("Error al actualizar el perfil: " . $e->getMessage());
    }
} else {
    // Mostrar formulario de actualización del perfil
    echo '<form method="POST" action="">
            <label for="username">Nuevo Nombre de Usuario:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="email">Nuevo Correo Electrónico:</label>
            <input type="email" id="email" name="email" required><br>
            <button type="submit">Actualizar</button>
          </form>';
}
?>
