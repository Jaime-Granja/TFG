window.onload = function () {
    let logOut = document.getElementById("logOut")
    logOut.addEventListener("click", atras)
    function atras() {
    
            window.location.href = "index.html"
       
       
    }
    }